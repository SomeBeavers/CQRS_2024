﻿namespace ConsoleApp_Core;

public class TestCommand
{
    public void Test()
    {
        string t = 1.ToString();
        var list = new List<string>();
    }

}
public class TestCommandQuery
{
    public void Test()
    {
        string t = 1.ToString();
        var list = new List<string>();
    }

}